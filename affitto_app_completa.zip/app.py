
[CODICE APP.PY — omesso per brevità in questo commento ma sarà ricreato nel file]
